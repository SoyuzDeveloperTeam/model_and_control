//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "USOFrm.h"
#include "USOData.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TUsoForm *UsoForm;
//---------------------------------------------------------------------------
__fastcall TUsoForm::TUsoForm(TComponent* Owner)
        : TForm(Owner)
{


}
//---------------------------------------------------------------------------

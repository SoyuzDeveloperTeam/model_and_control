
static AnsiString GSO_String;
static AnsiString BFI_action_str1[11] = {"SXFQLA","LASAOJF","QRPNAW","UCPE","IAQR SB","SB-2JNQ","RAIR SB","IACJS","PBMFT","IAC LPO","QRJYAM"};
static AnsiString BFI_action_str2[8] = {"TFST E","TFST L","QRJYAM","IAWCAT","ACTPSTPQ","SOX","LURS1","LURS2"};
static AnsiString BFI_oper2str[4] = {"CLM EQP","CLM SLE","CLM EQP-BT","RAICPRPT"};
static AnsiString BFI_EmerStr[16] = {"OFT","OFT","JLC-1","JLC-2","BEUS-1","BEUS-2","EQP-B","EQP-N1","EQP-N2","SLE","LEU","ALS","LURS1","LURS2","ALS2","ALS3"};
static AnsiString BFI_InstrStr[] = {"OFT","QRFHE QFRFLM","OFJSQR BEUS","DR OF RFAMJI","QPCcZ RASWPE","OFT RFSURSA","IAQRFT JLC","PTS RFIFRC","PTLAI SLE",
"D PST","QUIcRd","PTS LCJT DL","OUHFO RR","PST IASC SE","OFT eQR","RUYO QRJYAM","OF CcLM L","OF QAS","PTL LURS QAS","RUYO JINFR","OFT IW","LPR VAIc","JSTFLMP TI"};



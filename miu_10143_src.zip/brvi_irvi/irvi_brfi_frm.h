//---------------------------------------------------------------------------

#ifndef irvi_brfi_frmH
#define irvi_brfi_frmH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
class TIrBrForm : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TPanel *Panel1;
        TLabel *Label1;
        TPanel *i1;
        TPanel *i2;
        TPanel *i3;
        TPanel *i4;
        TPanel *i7;
        TPanel *i6;
        TPanel *i5;
        TPanel *i8;
        TPanel *i9;
        TPanel *i10;
        TPanel *i11;
        TPanel *i12;
        TPanel *i13;
        TPanel *i14;
        TPanel *i15;
        TImage *Image1;
        TSpeedButton *SpeedButton2;
        TSpeedButton *SpeedButton10;
        TSpeedButton *SpeedButton11;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton5;
        TSpeedButton *SpeedButton6;
        TSpeedButton *SpeedButton7;
        TSpeedButton *SpeedButton8;
        TSpeedButton *SpeedButton9;
        TSpeedButton *SpeedButton12;
        TSpeedButton *SpeedButton13;
        TSpeedButton *SpeedButton14;
        TSpeedButton *SpeedButton15;
        TSpeedButton *SpeedButton16;
        TSpeedButton *SpeedButton17;
        TSpeedButton *SpeedButton18;
        TSpeedButton *SpeedButton1;
        TTimer *irvi_send_t;
        TTimer *Timer1;
        void __fastcall SpeedButton9Click(TObject *Sender);
        void __fastcall SpeedButton12Click(TObject *Sender);
        void __fastcall SpeedButton17Click(TObject *Sender);
        void __fastcall SpeedButton14Click(TObject *Sender);
        void __fastcall SpeedButton16Click(TObject *Sender);
        void __fastcall SpeedButton18Click(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall SpeedButton5Click(TObject *Sender);
        void __fastcall SpeedButton6Click(TObject *Sender);
        void __fastcall SpeedButton10Click(TObject *Sender);
        void __fastcall SpeedButton11Click(TObject *Sender);
        void __fastcall SpeedButton4Click(TObject *Sender);
        void __fastcall SpeedButton7Click(TObject *Sender);
        void __fastcall SpeedButton8Click(TObject *Sender);
        void __fastcall SpeedButton15Click(TObject *Sender);
        void __fastcall irvi_send_tTimer(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TIrBrForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TIrBrForm *IrBrForm;
//---------------------------------------------------------------------------
#endif

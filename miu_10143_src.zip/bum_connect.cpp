//---------------------------------------------------------------------------


#pragma hdrstop

#include "bum_connect.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

double r_to_gr = 57.29577951308232;

void NU_pack_for_bum (void)
{
double mili =0.001;
}

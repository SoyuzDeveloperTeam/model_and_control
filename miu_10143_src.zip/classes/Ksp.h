//---------------------------------------------------------------------------

#ifndef KspH
#define KspH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
//---------------------------------------------------------------------------
class PACKAGE TKsp : public TGraphicControl
{
private:
protected:
public:
        __fastcall TKsp(TComponent* Owner);
__published:
};
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "sm_ssvp_PX.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tsm_ssvp_plx_frm *sm_ssvp_plx_frm;
//---------------------------------------------------------------------------
__fastcall Tsm_ssvp_plx_frm::Tsm_ssvp_plx_frm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall Tsm_ssvp_plx_frm::Timer1Timer(TObject *Sender)
{
bvs_mode->Caption="No data";
kruki->Caption="No data";
upor->Caption="No data";
kr_p1->Caption="  -";
kr_p2->Caption="No data";
}
//---------------------------------------------------------------------------



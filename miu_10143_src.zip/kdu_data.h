//---------------------------------------------------------------------------

#ifndef kdu_dataH
#define kdu_dataH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TKDUform : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *rhb1;
        TLabel *Label7;
        TLabel *ro1;
        TLabel *Label9;
        TLabel *rg1;
        TLabel *Label11;
        TLabel *o1_zapas;
        TLabel *g1_zapas;
        TLabel *Label16;
        TLabel *Label17;
        TGroupBox *GroupBox2;
        TLabel *Label18;
        TLabel *Label19;
        TLabel *Label20;
        TLabel *Label21;
        TLabel *Label22;
        TLabel *rhb2;
        TLabel *Label24;
        TLabel *Label25;
        TLabel *Label26;
        TLabel *Label27;
        TLabel *Label28;
        TLabel *Label29;
        TLabel *Label30;
        TLabel *Label31;
        TLabel *Label32;
        TGroupBox *GroupBox3;
        TLabel *Label33;
        TLabel *Label34;
        TLabel *Label37;
        TLabel *Label38;
        TLabel *Label39;
        TLabel *fuel_ost;
        TLabel *Label43;
        TGroupBox *GroupBox4;
        TLabel *Label35;
        TLabel *Label36;
        TLabel *Label40;
        TLabel *Label41;
        TLabel *Label45;
        TLabel *Label46;
        TLabel *Label47;
        TLabel *Label48;
        TLabel *rud_rash;
        TLabel *Label50;
        TLabel *Label51;
        TLabel *Label53;
        TGroupBox *GroupBox5;
        TLabel *Label44;
        TLabel *Label54;
        TLabel *Label55;
        TLabel *Label56;
        TLabel *Label57;
        TLabel *Label58;
        TButton *Button1;
        TPanel *kdu_dhb1;
        TPanel *kdu_dhb2;
        TTimer *Timer1;
        TButton *Button2;
        TButton *Button3;
        TLabel *Label6;
        TGroupBox *GroupBox6;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton2;
        TDateTimePicker *Tskd;
        TLabel *Label8;
        TLabel *Label10;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TComboBox *tormimp;
        TEdit *fuel;
        TLabel *Label23;
        TLabel *Label52;
        TTimer *Timer2;
        TBitBtn *BitBtn1;
        TStaticText *ts4_5;
        TStaticText *ts4_6;
        TLabel *Label59;
        TLabel *Label60;
        TLabel *Label61;
        TLabel *Label62;
        TLabel *mass_tpk;
        TLabel *Label64;
        TLabel *Label65;
        TEdit *Edit1;
        TLabel *kdu_O1;
        TLabel *Label63;
        TLabel *vp;
        TLabel *Label66;
        TLabel *Label67;
        TLabel *Label68;
        TLabel *Label69;
        TLabel *Label71;
        TLabel *Label72;
        TLabel *Label73;
        TEdit *Edit2;
        TLabel *Label74;
        TLabel *Label75;
        TTimer *USO_Otr_Timer;
        TBitBtn *BitBtn2;
        TTimer *Timer3;
        TLabel *Label76;
        TLabel *Label77;
        TLabel *Label78;
        TLabel *Label79;
        TLabel *Label80;
        TLabel *Label81;
        TLabel *SDR1_label;
        TLabel *SDR2_label;
        TLabel *DRO1_label;
        TLabel *DRG1_label;
        TLabel *Label86;
        TLabel *Label87;
        TLabel *Label88;
        TLabel *Label89;
        TLabel *Label90;
        TLabel *Label91;
        TLabel *Label92;
        TLabel *Label93;
        TLabel *Label94;
        TStaticText *NadduvKdu;
        TLabel *Label95;
        TLabel *Label96;
        TLabel *Label97;
        TLabel *Label98;
        TLabel *Label99;
        TLabel *Label100;
        TLabel *Label70;
        TLabel *Label101;
        TLabel *Label102;
        TLabel *Label103;
        TLabel *Label104;
        TLabel *Label105;
        TLabel *Label106;
        TLabel *Label107;
        TLabel *Label108;
        TLabel *Label109;
        TLabel *Label110;
        TLabel *Label111;
        TLabel *Label112;
        TLabel *Label113;
        TLabel *Label114;
        TLabel *Label115;
        TLabel *Label116;
        TLabel *Label117;
        TLabel *Label118;
        TLabel *Label119;
        TLabel *Label120;
        TLabel *Label121;
        TLabel *Label122;
        TLabel *Label123;
        TLabel *Label124;
        TLabel *Label125;
        TLabel *Label126;
        TLabel *Label127;
        TLabel *Label128;
        TLabel *Label129;
        TLabel *Label130;
        TLabel *Label131;
        TLabel *Label132;
        TStaticText *StaticText2;
        TStaticText *StaticText3;
        TStaticText *StaticText4;
        TStaticText *StaticText5;
        TStaticText *StaticText6;
        TLabel *Label82;
        TLabel *Label83;
        TLabel *Label133;
        TLabel *Label134;
        TTimer *sps_data;
        TTimer *kdu_math_t;
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Timer2Timer(TObject *Sender);
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall USO_Otr_TimerTimer(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall sps_dataTimer(TObject *Sender);
        void __fastcall kdu_math_tTimer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TKDUform(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKDUform *KDUform;
//---------------------------------------------------------------------------
#endif

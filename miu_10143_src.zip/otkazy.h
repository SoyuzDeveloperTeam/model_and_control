//---------------------------------------------------------------------------

#ifndef otkazyH
#define otkazyH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class Totkazy_frm : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TCheckBox *CheckBox1;
        TCheckBox *CheckBox2;
        TCheckBox *CheckBox3;
        TCheckBox *CheckBox4;
        TCheckBox *CheckBox5;
        TCheckBox *CheckBox6;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TCheckBox *CheckBox7;
        TCheckBox *CheckBox8;
        TCheckBox *CheckBox9;
        TLabel *Label7;
        TCheckBox *CheckBox10;
        TCheckBox *CheckBox11;
        TCheckBox *CheckBox12;
        TLabel *Label8;
        TCheckBox *CheckBox13;
        TCheckBox *CheckBox14;
        TCheckBox *CheckBox15;
        TButton *Button1;
        TGroupBox *GroupBox2;
        TCheckBox *CheckBox16;
        TCheckBox *CheckBox17;
        TCheckBox *CheckBox18;
        TCheckBox *CheckBox19;
        TCheckBox *CheckBox20;
        TCheckBox *CheckBox21;
        TGroupBox *GroupBox3;
        TCheckBox *CheckBox22;
        TCheckBox *CheckBox23;
        TCheckBox *CheckBox24;
        TCheckBox *CheckBox25;
        TCheckBox *CheckBox26;
        TCheckBox *CheckBox27;
        TCheckBox *CheckBox28;
        TLabel *Label9;
        TPanel *Panel1;
        TGroupBox *GroupBox4;
        TCheckBox *CheckBox29;
        TCheckBox *CheckBox30;
        TGroupBox *GroupBox5;
        TCheckBox *CheckBox31;
        TCheckBox *CheckBox32;
        TPanel *Panel2;
        TCheckBox *CheckBox33;
        TCheckBox *CheckBox34;
        TPanel *Panel3;
        TPanel *Panel4;
        TPanel *Panel5;
        TPanel *Panel6;
        TPanel *Panel7;
        TPanel *Panel8;
        TPanel *Panel9;
        TPanel *Panel10;
        TPanel *Panel11;
        TPanel *Panel12;
        TPanel *Panel13;
        TPanel *Panel14;
        TPanel *Panel15;
        TGroupBox *GroupBox6;
        TCheckBox *CheckBox35;
        TCheckBox *CheckBox36;
        TCheckBox *CheckBox37;
        TCheckBox *CheckBox38;
        TCheckBox *CheckBox39;
        TCheckBox *CheckBox40;
        TGroupBox *GroupBox7;
        TPanel *Panel16;
        TGroupBox *GroupBox8;
        TCheckBox *CheckBox41;
        TCheckBox *CheckBox42;
        TCheckBox *CheckBox43;
        TCheckBox *CheckBox44;
        TCheckBox *CheckBox45;
        TCheckBox *CheckBox46;
        TCheckBox *CheckBox47;
        TCheckBox *CheckBox48;
        TGroupBox *GroupBox9;
        TCheckBox *CheckBox49;
        TCheckBox *CheckBox50;
        TPanel *Panel17;
        TPanel *Panel18;
        TPanel *Panel19;
        TPanel *Panel20;
        TPanel *Panel21;
        TPanel *Panel22;
        TPanel *Panel23;
        TPanel *Panel24;
        TPanel *Panel25;
        TPanel *Panel26;
        TPanel *Panel27;
        TPanel *Panel28;
        TPanel *Panel29;
        TPanel *Panel30;
        TGroupBox *GroupBox10;
        TCheckBox *CheckBox51;
        TCheckBox *CheckBox52;
        TTimer *Timer1;
        void __fastcall CheckBox16Click(TObject *Sender);
        void __fastcall CheckBox17Click(TObject *Sender);
        void __fastcall CheckBox19Click(TObject *Sender);
        void __fastcall CheckBox22Click(TObject *Sender);
        void __fastcall CheckBox26Click(TObject *Sender);
        void __fastcall CheckBox13Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall Totkazy_frm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Totkazy_frm *otkazy_frm;
//---------------------------------------------------------------------------
#endif
 
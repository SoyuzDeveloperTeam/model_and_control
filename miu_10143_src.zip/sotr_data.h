#ifndef _sotr_data
#define _sotr_data
static double bln_o2_sa_pr;
static double bln_o2_PxO_pr_1;
static double bln_o2_PxO_pr_2;

int bymass=10;

static double vacuum_const = 0.000001;

#endif // _sotr_data

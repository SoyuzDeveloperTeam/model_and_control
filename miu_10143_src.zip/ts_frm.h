//---------------------------------------------------------------------------

#ifndef ts_frmH
#define ts_frmH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class Tts_form : public TForm
{
__published:	// IDE-managed Components
        TLabel *ts1_label;
        TStaticText *ts1_1;
        TStaticText *ts1_2;
        TStaticText *ts1_3;
        TStaticText *ts1_4;
        TStaticText *ts1_5;
        TStaticText *ts1_6;
        TLabel *ts2_label;
        TStaticText *ts2_1;
        TStaticText *ts2_2;
        TStaticText *ts2_3;
        TStaticText *ts2_4;
        TStaticText *ts2_5;
        TStaticText *ts2_6;
        TLabel *ts3_label;
        TStaticText *ts3_1;
        TStaticText *ts3_2;
        TStaticText *ts3_3;
        TStaticText *ts3_4;
        TStaticText *ts3_5;
        TStaticText *ts3_6;
        TLabel *ts4_label;
        TStaticText *ts4_1;
        TStaticText *ts4_2;
        TStaticText *ts4_3;
        TStaticText *ts4_4;
        TStaticText *ts4_5;
        TStaticText *ts4_6;
        TLabel *ls5_label;
        TStaticText *ts5_1;
        TStaticText *ts5_2;
        TStaticText *ts5_3;
        TStaticText *ts5_4;
        TStaticText *ts5_5;
        TStaticText *ts5_6;
        TLabel *ts6_label;
        TStaticText *ts6_1;
        TStaticText *ts6_2;
        TStaticText *ts6_3;
        TStaticText *ts6_4;
        TStaticText *ts6_5;
        TStaticText *ts6_6;
        TLabel *ts7_label;
        TStaticText *ts7_1;
        TStaticText *ts7_2;
        TStaticText *ts7_3;
        TStaticText *ts7_4;
        TStaticText *ts7_5;
        TStaticText *ts7_6;
        TLabel *ts8_label;
        TStaticText *ts8_1;
        TStaticText *ts8_2;
        TStaticText *ts8_3;
        TStaticText *ts8_4;
        TStaticText *ts8_5;
        TStaticText *ts8_6;
        TStaticText *tsa1;
        TStaticText *tsa2;
        TStaticText *tsa3;
        TStaticText *tsa4;
        TStaticText *tsa5;
        TStaticText *tsa6;
        TStaticText *tsb1;
        TStaticText *tsb2;
        TStaticText *tsb3;
        TStaticText *tsb4;
        TStaticText *tsb5;
        TStaticText *tsb6;
        TTimer *Timer1;
        void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall Tts_form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tts_form *ts_form;
//---------------------------------------------------------------------------
#endif

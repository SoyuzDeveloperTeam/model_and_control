//---------------------------------------------------------------------------

#ifndef zakon_uprH
#define zakon_uprH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Chart.hpp>
#include <ExtCtrls.hpp>
#include <Series.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class Tzakon_upr_frm : public TForm
{
__published:	// IDE-managed Components
        TChart *zakon_uprav;
        TFastLineSeries *Series1;
        TFastLineSeries *Series2;
        TFastLineSeries *Series3;
        TFastLineSeries *Series4;
        TFastLineSeries *Series5;
        TFastLineSeries *Series6;
        TMainMenu *MainMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TFastLineSeries *Series7;
        TMenuItem *N7501;
        TMenuItem *N15001;
        TMenuItem *N30001;
        TMenuItem *N60001;
        TMenuItem *N150001;
        TPointSeries *Series8;
        TTimer *Timer1;
        TFastLineSeries *Series9;
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TButton *Button1;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall N2Click(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall MainFormN3001Click(TObject *Sender);
        void __fastcall N7501Click(TObject *Sender);
        void __fastcall N15001Click(TObject *Sender);
        void __fastcall N30001Click(TObject *Sender);
        void __fastcall N60001Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall Tzakon_upr_frm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tzakon_upr_frm *zakon_upr_frm;
//---------------------------------------------------------------------------
#endif
